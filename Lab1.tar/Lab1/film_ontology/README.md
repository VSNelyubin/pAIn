How to open file `film_ontology.xml`:  

+ open [this](https://app.diagrams.net/)  
+ create blank diagram  
+ Extras -> Edit Diagram -> enter content of file `film_ontology.xml`  